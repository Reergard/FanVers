import { Line } from "../../components/Line";
import { Navigation } from "../../components/Navigation";
import { NavigationWrapper } from "../../components/NavigationWrapper";
import { PropertyDefault } from "../../components/PropertyDefault";
import { StarFill5 } from "../../icons/StarFill5";
import { StarLight } from "../../icons/StarLight";
import "./style.css";

export const HomePage = () => {
  return (
    <div className="home-page">
      <img className="element" alt="Element" src="/img/1sr-glcht4s-1.png" />

      <img className="element-2" alt="Element" src="/img/3-1.svg" />

      <div className="rating">
        <div className="rating-2">
          <div className="rectangle-2" />

          <div className="group">
            <StarLight className="star-light" color="#C2BD68" />
            <StarFill5 className="star-fill" color="#C2BD68" />
            <StarFill5 className="star-fill-5" color="#C2BD68" />
            <StarFill5 className="star-fill-1" color="#C2BD68" />
            <StarFill5 className="star-fill-5-instance" color="#C2BD68" />
          </div>

          <div className="text-wrapper-2">якість перекладу</div>
        </div>

        <div className="rating-3">
          <div className="rectangle-2" />

          <div className="text-wrapper-3">рейтинг твору</div>

          <div className="group-2">
            <StarLight className="star-light" color="#C2BD68" />
            <StarFill5 className="star-fill" color="#C2BD68" />
            <StarFill5 className="star-fill-5" color="#C2BD68" />
            <StarFill5 className="star-fill-1" color="#C2BD68" />
            <StarFill5 className="star-fill-5-instance" color="#C2BD68" />
          </div>
        </div>
      </div>

      <div className="text-book">
        <div className="text">
          <div className="rectangle-3" />

          <p className="p">
            Цзянь Чен - загальновизнаний експерт,+ номер один у бойових
            мистецтвах Цзяньху. Його майстерність володіння мечем виходила за
            межі досконалості і була непереможною в бою. Після битви з видатним
            майстром Дугу Кьюбей, який зник безвісти понад сто років тому, Цзянь
            Чен не витримав поранень і помер.
            <br />
            <br />
            Після смерті Цзянь Чена виявився в абсолютно новому світі. Його
            швидкий розвиток привів до послідовного нападу ворогів, які завдали
            йому серйозних травм.
            <br />
            На порозі смерті його дух мутував, і з цього моменту він ступив на
            зовсім інший шлях мистецтва меча, щоб стати богом меча свого
            покоління.
          </p>
        </div>

        <div className="text-wrapper-4">ХАОТИЧНИЙ БОГ МЕЧА</div>

        <PropertyDefault
          className="button"
          rectangle="/img/rectangle-6-1.svg"
          rectangleClassName="property-1-default"
        />
      </div>

      <Navigation className="navigation-4" />
      <NavigationWrapper className="navigation-5" />
      <Line className="line-instance" text="НОВИНКИ" />
    </div>
  );
};
