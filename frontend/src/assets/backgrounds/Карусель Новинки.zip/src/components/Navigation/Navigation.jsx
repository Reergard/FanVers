import "./style.css";

export const Navigation = ({ className }) => {
  return <div className={`navigation ${className}`} />;
};
