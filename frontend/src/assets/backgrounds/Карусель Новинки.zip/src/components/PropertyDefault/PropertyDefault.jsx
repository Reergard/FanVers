import "./style.css";

export const PropertyDefault = ({
  className,
  rectangleClassName,
  rectangle = "/img/rectangle-6.svg",
}) => {
  return (
    <div className={`property-default ${className}`}>
      <img
        className={`rectangle ${rectangleClassName}`}
        alt="Rectangle"
        src={rectangle}
      />

      <div className="text-wrapper">читати</div>
    </div>
  );
};
