export { PropertyDefault } from "./PropertyDefault";
