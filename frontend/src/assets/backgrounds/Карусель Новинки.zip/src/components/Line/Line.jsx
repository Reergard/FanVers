import "./style.css";

export const Line = ({ className, text = "РЕКЛАМА" }) => {
  return (
    <div className={`line ${className}`}>
      <div className="div">{text}</div>

      <img className="img" alt="Line" src="/img/line-51.svg" />
    </div>
  );
};
