import "./style.css";

export const NavigationWrapper = ({ className }) => {
  return <div className={`navigation-wrapper ${className}`} />;
};
