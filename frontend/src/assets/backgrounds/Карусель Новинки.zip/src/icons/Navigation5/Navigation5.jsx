export const Navigation5 = ({ className }) => {
  return (
    <svg
      className={`navigation-5 ${className}`}
      fill="none"
      height="101"
      viewBox="0 0 101 101"
      width="101"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M29.5312 50.516L71.1967 50.2117M29.5312 50.516L46.0757 33.728M29.5312 50.516L46.3191 67.0605"
        stroke="#C0B7E8"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3"
      />
    </svg>
  );
};
