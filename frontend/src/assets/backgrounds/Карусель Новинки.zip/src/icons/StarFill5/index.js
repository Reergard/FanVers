export { StarFill5 } from "./StarFill5";
