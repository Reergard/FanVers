export const Navigation4 = ({ className }) => {
  return (
    <svg
      className={`navigation-4 ${className}`}
      fill="none"
      height="100"
      viewBox="0 0 100 100"
      width="100"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M70.8337 50L29.167 50M70.8337 50L54.167 66.6667M70.8337 50L54.167 33.3333"
        stroke="#C0B7E8"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3"
      />
    </svg>
  );
};
