export { OutlineArrowSmallRight } from "./OutlineArrowSmallRight";
