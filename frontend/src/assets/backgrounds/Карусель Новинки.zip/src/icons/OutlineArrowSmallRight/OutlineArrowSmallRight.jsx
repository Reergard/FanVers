export const OutlineArrowSmallRight = ({ className }) => {
  return (
    <svg
      className={`outline-arrow-small-right ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M17 12L7 12M17 12L13 16M17 12L13 8"
        stroke="#001A72"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
    </svg>
  );
};
