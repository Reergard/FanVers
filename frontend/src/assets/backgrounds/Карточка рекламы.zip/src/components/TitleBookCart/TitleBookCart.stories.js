import { TitleBookCart } from ".";

export default {
  title: "Components/TitleBookCart",
  component: TitleBookCart,
};

export const Default = {
  args: {
    className: "",
  },
};
