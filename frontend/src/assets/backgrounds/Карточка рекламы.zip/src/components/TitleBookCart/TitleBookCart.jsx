import "./style.css";

export const TitleBookCart = ({ className }) => {
  return (
    <div className={`title-book-cart ${className}`}>
      <div className="text-wrapper-2">ХАОТИЧНИЙ БОГ МЕЧА</div>
    </div>
  );
};
