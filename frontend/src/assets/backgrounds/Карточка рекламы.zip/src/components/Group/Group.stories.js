import { Group } from ".";

export default {
  title: "Components/Group",
  component: Group,

  argTypes: {
    property1: {
      options: ["variant-4", "variant-2", "variant-3", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "variant-4",
    className: "",
    divClassName: "",
    divClassNameOverride: "",
    ellipse: "/img/ellipse-102-1.svg",
  },
};
