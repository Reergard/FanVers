import "./style.css";

export const Group = ({
  property1,
  className,
  divClassName,
  divClassNameOverride,
  ellipse = "/img/ellipse-102-1.svg",
}) => {
  return (
    <div className={`group ${property1} ${className}`}>
      <div className={`text-wrapper-3 ${divClassName}`}>18</div>

      <div className={`text-wrapper-4 ${divClassNameOverride}`}>+</div>

      <img
        className="ellipse"
        alt="Ellipse"
        src={
          property1 === "variant-4"
            ? "/img/ellipse-102-2.svg"
            : property1 === "variant-3"
              ? "/img/ellipse-102-3.svg"
              : property1 === "variant-2"
                ? "/img/ellipse-102-4.svg"
                : ellipse
        }
      />
    </div>
  );
};
