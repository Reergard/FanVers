import "./style.css";

export const ButtomDefault = ({ className, divClassName }) => {
  return (
    <div className={`buttom-default ${className}`}>
      <div className={`text-wrapper ${divClassName}`}>читати</div>
    </div>
  );
};
