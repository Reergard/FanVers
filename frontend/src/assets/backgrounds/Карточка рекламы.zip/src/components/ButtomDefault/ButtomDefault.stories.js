import { ButtomDefault } from ".";

export default {
  title: "Components/ButtomDefault",
  component: ButtomDefault,
};

export const Default = {
  args: {
    className: "",
    divClassName: "",
  },
};
