import { Navigation3 } from "../../icons/Navigation3";
import "./style.css";

export const PropertyDefaultWrapper = ({
  property1,
  className,
  icon = <Navigation3 className="navigation-3" />,
}) => {
  return (
    <div
      className={`property-default-wrapper property-1-2-${property1} ${className}`}
    >
      {icon}
    </div>
  );
};
