import { ImageBookCart } from ".";

export default {
  title: "Components/ImageBookCart",
  component: ImageBookCart,
};

export const Default = {
  args: {
    className: "",
    groupEllipse: "/img/ellipse-102.svg",
    img: "/img/image.svg",
  },
};
