import { Group } from "../Group";
import "./style.css";

export const ImageBookCart = ({
  className,
  groupEllipse = "/img/ellipse-102.svg",
  img = "/img/image.svg",
}) => {
  return (
    <div className={`image-book-cart ${className}`}>
      <Group
        className="group-80"
        divClassName="group-instance"
        divClassNameOverride="group-80-instance"
        ellipse={groupEllipse}
        property1="default"
      />
      <img className="img" alt="Img" src={img} />

      <div className="a">A</div>
    </div>
  );
};
