import { Navigation } from ".";

export default {
  title: "Components/Navigation",
  component: Navigation,

  argTypes: {
    property1: {
      options: ["active", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "active",
    className: "",
    vector: "/img/vector-11.svg",
  },
};
