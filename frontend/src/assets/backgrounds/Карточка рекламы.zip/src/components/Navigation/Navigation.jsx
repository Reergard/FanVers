import "./style.css";

export const Navigation = ({
  property1,
  className,
  vector = "/img/vector-11.svg",
}) => {
  return (
    <div className={`navigation property-1-1-${property1} ${className}`}>
      <img
        className="vector"
        alt="Vector"
        src={
          property1 === "active" ? "/img/vector-14.svg" : "/img/vector-10.svg"
        }
      />

      <img
        className="vector-2"
        alt="Vector"
        src={property1 === "active" ? "/img/vector-15.svg" : vector}
      />

      <img
        className="vector-3"
        alt="Vector"
        src={
          property1 === "active" ? "/img/vector-16.svg" : "/img/vector-12.svg"
        }
      />

      <img
        className="vector-4"
        alt="Vector"
        src={
          property1 === "active" ? "/img/vector-17.svg" : "/img/vector-13.svg"
        }
      />
    </div>
  );
};
