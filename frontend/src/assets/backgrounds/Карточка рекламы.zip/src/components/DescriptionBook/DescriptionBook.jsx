import "./style.css";

export const DescriptionBook = ({ className, divClassName }) => {
  return (
    <div className={`description-book ${className}`}>
      <p className={`div ${divClassName}`}>
        Цзянь Чен - загальновизнаний експерт,+ номер один у бойових мистецтвах
        Цзяньху. Його майстерність володіння мечем виходила за межі досконалості
        і була непереможною в бою. Після битви з видатним майстром Дугу Кьюбей,
        який зник безвісти понад сто років тому, Цзянь Чен не витримав поранень
        і помер...
      </p>
    </div>
  );
};
