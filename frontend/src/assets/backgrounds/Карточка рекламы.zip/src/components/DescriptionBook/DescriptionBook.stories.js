import { DescriptionBook } from ".";

export default {
  title: "Components/DescriptionBook",
  component: DescriptionBook,
};

export const Default = {
  args: {
    className: "",
    divClassName: "",
  },
};
