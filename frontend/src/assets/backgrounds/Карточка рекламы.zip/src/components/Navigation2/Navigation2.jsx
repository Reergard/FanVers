import "./style.css";

export const Navigation2 = ({
  property1,
  className,
  group = "/img/group-3.png",
  vector = "/img/vector-4.svg",
  img = "/img/vector-5.svg",
  vector1 = "/img/vector-6.svg",
  vector2 = "/img/vector-7.svg",
}) => {
  return (
    <div className={`navigation-2 property-1-3-${property1} ${className}`}>
      <img
        className="group-2"
        alt="Group"
        src={property1 === "active" ? group : "/img/group-2.png"}
      />

      <img
        className="vector-5"
        alt="Vector"
        src={property1 === "active" ? vector : "/img/vector.svg"}
      />

      <img
        className="vector-6"
        alt="Vector"
        src={property1 === "active" ? img : "/img/vector-1.svg"}
      />

      <img
        className="vector-7"
        alt="Vector"
        src={property1 === "active" ? vector1 : "/img/vector-2.svg"}
      />

      <img
        className="vector-8"
        alt="Vector"
        src={property1 === "active" ? vector2 : "/img/vector-3.svg"}
      />
    </div>
  );
};
