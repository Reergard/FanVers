import { Navigation2 } from ".";

export default {
  title: "Components/Navigation2",
  component: Navigation2,

  argTypes: {
    property1: {
      options: ["active", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "active",
    className: "",
    group: "/img/group-3.png",
    vector: "/img/vector-4.svg",
    img: "/img/vector-5.svg",
    vector1: "/img/vector-6.svg",
    vector2: "/img/vector-7.svg",
  },
};
