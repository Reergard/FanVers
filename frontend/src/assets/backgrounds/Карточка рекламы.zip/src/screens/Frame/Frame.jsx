import { ButtomDefault } from "../../components/ButtomDefault";
import { DescriptionBook } from "../../components/DescriptionBook";
import { ImageBookCart } from "../../components/ImageBookCart";
import { Navigation } from "../../components/Navigation";
import { Navigation2 } from "../../components/Navigation2";
import { PropertyDefaultWrapper } from "../../components/PropertyDefaultWrapper";
import { TitleBookCart } from "../../components/TitleBookCart";
import { Navigation32 } from "../../icons/Navigation32";
import { Navigation33 } from "../../icons/Navigation33";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="rectangle" />

      <div className="group-3">
        <div className="book-card">
          <ButtomDefault
            className="buttom-2-default"
            divClassName="buttom-default-instance"
          />
          <DescriptionBook
            className="description-book-cart"
            divClassName="description-book-instance"
          />
          <img className="vector-9" alt="Vector" src="/img/vector-10-1.svg" />

          <TitleBookCart className="title-book-cart-instance" />
          <div className="ellipse-2" />

          <div className="ellipse-3" />

          <ImageBookCart
            className="image-book-cart-instance"
            groupEllipse="/img/ellipse-102-5.svg"
            img="/img/1.svg"
          />
        </div>

        <div className="navigation-cart">
          <div className="navigation-wrapper">
            <Navigation
              className="navigation-1"
              property1="default"
              vector="/img/vector-19.svg"
            />
          </div>

          <PropertyDefaultWrapper
            className="navigation-instance"
            icon={<Navigation32 className="icon-instance-node" />}
            property1="default"
          />
          <PropertyDefaultWrapper
            className="navigation-instance"
            icon={<Navigation33 className="icon-instance-node" />}
            property1="active"
          />
          <Navigation2
            className="navigation-2-instance"
            group="/img/group-1.png"
            img="/img/vector-23.svg"
            property1="active"
            vector="/img/vector-22.svg"
            vector1="/img/vector-24.svg"
            vector2="/img/vector-25.svg"
          />
        </div>
      </div>
    </div>
  );
};
