export const Navigation33 = ({ className }) => {
  return (
    <svg
      className={`navigation3-3 ${className}`}
      fill="none"
      height="18"
      viewBox="0 0 18 18"
      width="18"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" filter="url(#filter0_d_922_18909)">
        <path
          className="path"
          d="M13.6512 4.20445C12.5075 4.08337 11.1963 3.88844 10.6249 3.04485C10.0464 2.19127 10.1917 1.17004 9.90461 0.257258C9.79918 -0.0773859 9.08423 -0.0940183 8.99298 0.257258C8.75289 1.18202 8.41092 2.12607 7.83949 2.96966C7.24059 3.85384 6.11546 4.0807 4.88578 4.1938C4.79187 4.20245 4.72099 4.23439 4.66784 4.27631C4.55355 4.2803 4.44281 4.2936 4.32763 4.2936C3.95997 4.29227 3.86074 4.73602 4.24347 4.78659C5.76374 4.98751 7.15467 5.36406 8.04061 6.36333C8.94693 7.38589 9.10549 8.60804 9.18346 9.80291C9.19763 10.0191 9.6477 10.0877 9.70883 9.85347C9.84704 9.3239 10.0898 8.80431 10.2315 8.27141C10.3724 7.74383 10.4512 7.20294 10.624 6.68068C10.795 6.16242 11.1175 5.85705 11.7447 5.61156C12.4101 5.35142 13.0931 5.11324 13.7664 4.86509C14.119 4.73469 14.0659 4.24836 13.6512 4.20445ZM9.76729 6.12516C9.59984 6.46313 9.49974 6.8164 9.43152 7.17566C9.28888 6.69732 9.06829 6.23826 8.71126 5.82378C8.27449 5.31683 7.64017 4.87973 6.90307 4.6329C6.83042 4.60895 6.75423 4.59632 6.68159 4.57636C7.35756 4.4566 7.96885 4.22042 8.43751 3.73941C8.83796 3.32826 9.11171 2.83195 9.32699 2.31635C9.42179 2.82197 9.58302 3.31295 9.9746 3.75072C10.4512 4.28428 11.137 4.54774 11.89 4.70009C10.9802 5.01411 10.1225 5.40664 9.76729 6.12516Z"
          fill="#F58807"
          fillOpacity="0.5"
          shapeRendering="crispEdges"
        />
      </g>

      <defs className="defs">
        <filter
          className="filter"
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
          height="18"
          id="filter0_d_922_18909"
          width="18"
          x="0"
          y="0"
        >
          <feFlood
            className="fe-flood"
            floodOpacity="0"
            result="BackgroundImageFix"
          />

          <feColorMatrix
            className="fe-color-matrix"
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />

          <feOffset className="fe-offset" dy="4" />

          <feGaussianBlur className="fe-gaussian-blur" stdDeviation="2" />

          <feComposite
            className="fe-composite"
            in2="hardAlpha"
            operator="out"
          />

          <feColorMatrix
            className="fe-color-matrix"
            type="matrix"
            values="0 0 0 0 0.960784 0 0 0 0 0.533333 0 0 0 0 0.027451 0 0 0 0.5 0"
          />

          <feBlend
            className="fe-blend"
            in2="BackgroundImageFix"
            mode="normal"
            result="effect1_dropShadow_922_18909"
          />

          <feBlend
            className="fe-blend"
            in="SourceGraphic"
            in2="effect1_dropShadow_922_18909"
            mode="normal"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
};
